import os, json, sqlite3, hashlib
from pathlib import Path
from typing import List
import numpy as np
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from pypdf import PdfReader
from docx import Document as DocxDocument

load_dotenv()
DB_PATH = os.getenv("DATABASE_PATH", "novacore.db")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "15"))
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

app = FastAPI(title="Novacore RAG API", version="0.1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=False,
    allow_methods=["GET", "POST"], allow_headers=["*"]
)
model = None

def get_model():
    global model
    if model is None:
        model = SentenceTransformer(MODEL_NAME)
    return model

def db():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        content TEXT NOT NULL,
        embedding TEXT NOT NULL
    )""")
    con.commit()
    return con

def extract_text(filename: str, data: bytes) -> str:
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        import io
        reader = PdfReader(io.BytesIO(data))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    if suffix == ".docx":
        import io
        doc = DocxDocument(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)
    if suffix in (".txt", ".md"):
        return data.decode("utf-8", errors="replace")
    raise HTTPException(400, "Supported formats: PDF, DOCX, TXT, MD")

def split_text(text: str, size=900, overlap=120):
    text = " ".join(text.split())
    if not text:
        return []
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - overlap
    return chunks

@app.get("/health")
def health():
    return {"ok": True, "app": "Novacore", "version": "0.1.0"}

@app.get("/documents")
def documents():
    con = db()
    rows = con.execute("SELECT filename, COUNT(*) FROM chunks GROUP BY filename ORDER BY filename").fetchall()
    con.close()
    return {"documents": [{"filename": r[0], "chunks": r[1]} for r in rows]}

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File exceeds {MAX_UPLOAD_MB} MB limit")
    text = extract_text(file.filename or "document.txt", data)
    chunks = split_text(text)
    if not chunks:
        raise HTTPException(400, "No readable text found in this file")
    embeddings = get_model().encode(chunks, normalize_embeddings=True)
    con = db()
    con.execute("DELETE FROM chunks WHERE filename = ?", (file.filename,))
    con.executemany(
        "INSERT INTO chunks(filename, content, embedding) VALUES (?, ?, ?)",
        [(file.filename, chunk, json.dumps(vec.tolist())) for chunk, vec in zip(chunks, embeddings)]
    )
    con.commit()
    con.close()
    return {"filename": file.filename, "chunks_added": len(chunks)}

class ChatRequest(BaseModel):
    message: str
    top_k: int = 4

@app.post("/chat")
def chat(req: ChatRequest):
    question = req.message.strip()
    if not question:
        raise HTTPException(400, "Message cannot be empty")
    con = db()
    rows = con.execute("SELECT filename, content, embedding FROM chunks").fetchall()
    con.close()
    if not rows:
        return {"answer": "আগে একটি PDF, DOCX, TXT বা MD ফাইল আপলোড করুন।", "sources": []}
    qv = get_model().encode([question], normalize_embeddings=True)[0]
    scored = []
    for filename, content, embedding in rows:
        vec = np.asarray(json.loads(embedding), dtype=np.float32)
        score = float(np.dot(qv, vec))
        scored.append((score, filename, content))
    scored.sort(key=lambda x: x[0], reverse=True)
    chosen = scored[:max(1, min(req.top_k, 8))]
    context = "\n\n".join(f"[{i+1}] {name}: {content}" for i, (_, name, content) in enumerate(chosen))
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if api_key:
        try:
            from google import genai
            client = genai.Client(api_key=api_key)
            prompt = (
                "Answer the user's question using only the context below. "
                "If the context does not contain the answer, say so. "
                "Reply in the user's language. Cite sources as [1], [2], etc.\n\n"
                f"CONTEXT:\n{context}\n\nQUESTION:\n{question}"
            )
            response = client.models.generate_content(
                model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
                contents=prompt
            )
            answer = response.text or "উত্তর তৈরি করা যায়নি।"
        except Exception:
            answer = "AI উত্তর তৈরি করা যায়নি। নিচে পাওয়া প্রাসঙ্গিক অংশগুলো দেওয়া হলো:\n\n" + context
    else:
        answer = "Gemini API key সেট করা নেই। প্রাসঙ্গিক নথির অংশগুলো:\n\n" + context
    return {
        "answer": answer,
        "sources": [{"number": i+1, "filename": name, "score": round(score, 4), "excerpt": content[:260]}
                    for i, (score, name, content) in enumerate(chosen)]
    }
